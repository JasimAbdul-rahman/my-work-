import tkinter as tk
from tkinter import ttk

# Create the main window
root = tk.Tk()
root.title("Registration Form")
root.geometry("450x450")
root.resizable(False, False)

# Function for the Register button
def register():
    print("Registration Successful!")

# Labels and Entry fields
tk.Label(root, text="Enter Name:", font=("Arial", 10)).place(x=50, y=30)
name_entry = tk.Entry(root, width=30)
name_entry.place(x=200, y=30)

tk.Label(root, text="Enter Email:", font=("Arial", 10)).place(x=50, y=70)
email_entry = tk.Entry(root, width=30)
email_entry.place(x=200, y=70)

tk.Label(root, text="Contact Number:", font=("Arial", 10)).place(x=50, y=110)
contact_entry = tk.Entry(root, width=30)
contact_entry.place(x=200, y=110)

# Gender Selection
tk.Label(root, text="Select Gender:", font=("Arial", 10)).place(x=50, y=150)
gender_var = tk.StringVar()
tk.Radiobutton(root, text="Male", variable=gender_var, value="Male").place(x=200, y=150)
tk.Radiobutton(root, text="Female", variable=gender_var, value="Female").place(x=260, y=150)
tk.Radiobutton(root, text="Others", variable=gender_var, value="Others").place(x=330, y=150)

# Country Selection
tk.Label(root, text="Select Country:", font=("Arial", 10)).place(x=50, y=190)
country_combobox = ttk.Combobox(root, values=["United States", "Canada", "United Kingdom", "Others"], width=27)
country_combobox.set("United States")  # Default value
country_combobox.place(x=200, y=190)

# Password fields
tk.Label(root, text="Enter Password:", font=("Arial", 10)).place(x=50, y=230)
password_entry = tk.Entry(root, show="*", width=30)
password_entry.place(x=200, y=230)

tk.Label(root, text="Re-Enter Password:", font=("Arial", 10)).place(x=50, y=270)
re_password_entry = tk.Entry(root, show="*", width=30)
re_password_entry.place(x=200, y=270)

# Register Button
register_button = tk.Button(root, text="Register", font=("Arial", 10), bg="lightgray", command=register)
register_button.place(x=200, y=320)

# Run the application
root.mainloop()