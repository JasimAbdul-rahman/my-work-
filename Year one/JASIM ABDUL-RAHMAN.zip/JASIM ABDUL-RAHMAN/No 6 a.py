
def get_valid_marks(prompt, max_value):
    marks = -1
    while marks < 0 or marks > max_value:
        marks_input = input(prompt)
        if marks_input.replace('.', '', 1).isdigit() and marks_input.count('.') <= 1:
            marks = float(marks_input)
            if marks < 0 or marks > max_value:
                print(f"Invalid input. Marks should be between 0 and {max_value}. Please try again.")
        else:
            print("Invalid input. Please enter a numeric value.")
    return marks


def calculate_final_grade(coursework, attendance, exam):
    coursework_weighted = (coursework / 30) * 25
    attendance_weighted = (attendance / 10) * 5
    exam_weighted = (exam / 100) * 70
    return coursework_weighted + attendance_weighted + exam_weighted

def display_results(students):
    best_student = None
    best_score = -1
    for student in students:
        print(f"\nStudent Name: {student['name']}")
        print(f"Coursework: {student['coursework']}/30 (Weighted: {(student['coursework'] / 30) * 25}%)")
        print(f"Attendance: {student['attendance']}/10 (Weighted: {(student['attendance'] / 10) * 5}%)")
        print(f"Exam: {student['exam']}/100 (Weighted: {(student['exam'] / 100) * 70}%)")
        print(f"Final Score: {student['final_grade']:.2f}%")

        if student['final_grade'] > best_score:
            best_score = student['final_grade']
            best_student = student['name']
    
   
    print(f"\nBest Performing Student: {best_student} with a score of {best_score:.2f}%")


def main():
    students = []
    
    for i in range(3):
        print(f"\nEnter data for Student {i+1}:")
        name = input("Enter the student's name: ")
        
        coursework = get_valid_marks("Enter the coursework marks (out of 30): ", 30)
        attendance = get_valid_marks("Enter the attendance marks (out of 10): ", 10)
        exam = get_valid_marks("Enter the exam marks (out of 100): ", 100)
        
        final_grade = calculate_final_grade(coursework, attendance, exam)
        
        students.append({
            "name": name,
            "coursework": coursework,
            "attendance": attendance,
            "exam": exam,
            "final_grade": final_grade
        })
    
    display_results(students)

if __name__ == "__main__":
    main()
