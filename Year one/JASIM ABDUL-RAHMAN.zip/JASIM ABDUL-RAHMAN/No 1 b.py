# Input: Get student IDs from the user
student_ids = input("Enter HEP student ID numbers separated by spaces: ").split()

# Sort the IDs
student_ids.sort()

# Output: Display the sorted IDs
print("Sorted HEP student IDs:", student_ids)