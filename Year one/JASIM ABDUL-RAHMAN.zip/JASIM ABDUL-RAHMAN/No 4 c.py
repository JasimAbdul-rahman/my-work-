def function(*args):
   
    if all(isinstance(arg, int) for arg in args):
        return sum(args)
    else:
        return None 

print(function(2.5, 3.4))  
print(function(2, 3, 4, 5))  
print(function("Adam Sandler", "Drew Barrymore")) 
print(function(False)) 
