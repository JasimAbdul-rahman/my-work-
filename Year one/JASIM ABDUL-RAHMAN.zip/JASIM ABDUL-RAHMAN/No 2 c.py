import tkinter as tk

def button_click(value):
    if value == "Clear":
        entry.delete(0, tk.END)
    elif value == "Enter":
        expression = entry.get()
        if validate_expression(expression):
            result = eval(expression)
            entry.delete(0, tk.END)
            entry.insert(tk.END, str(result))
        else:
            entry.delete(0, tk.END)
            entry.insert(tk.END, "Invalid")
    else:
        entry.insert(tk.END, value)

def validate_expression(expression):
    valid_chars = "0123456789+-*/.()"
    for char in expression:
        if char not in valid_chars:
            return False
    return True


root = tk.Tk()
root.title("Calculator")

entry = tk.Entry(root, width=30, font=("Arial", 14), justify="right")
entry.grid(row=0, column=0, columnspan=5, padx=5, pady=5)

buttons = [
    ("7", 1, 0), ("8", 1, 1), ("9", 1, 2), ("-", 1, 3), ("*", 1, 4),
    ("4", 2, 0), ("5", 2, 1), ("6", 2, 2), ("+", 2, 3), ("/", 2, 4),
    ("3", 3, 0), ("2", 3, 1), ("1", 3, 2), ("0", 3, 3), ("Enter", 3, 4),
    ("Clear", 4, 0)
]

for (text, row, col) in buttons:
    if text == "Clear":
        button = tk.Button(root, text=text, width=36, height=2, font=("Arial", 12),
                           command=lambda value=text: button_click(value))
        button.grid(row=row, column=col, columnspan=5, padx=3, pady=3)
    else:
        button = tk.Button(root, text=text, width=5, height=2, font=("Arial", 12),
                           command=lambda value=text: button_click(value))
        button.grid(row=row, column=col, padx=3, pady=3)

root.mainloop()