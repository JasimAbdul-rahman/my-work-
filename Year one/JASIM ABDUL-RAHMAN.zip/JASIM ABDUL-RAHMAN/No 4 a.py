def get_valid_input(prompt, is_float=False):
    while True:
        user_input = input(prompt)
        if is_float:
            if user_input.replace('.', '', 1).isdigit() and float(user_input) > 0:
                return float(user_input)
            else:
                print("Please enter a valid positive number.")
        else:
            if user_input.strip():
                return user_input
            else:
                print("Name cannot be empty. Please try again.")

def calculate_amount_payable(loan_amount, duration):
    daily_interest_rate = 1.5 / 100
    total_interest = loan_amount * daily_interest_rate * duration
    total_amount = loan_amount + total_interest
    return total_amount, total_interest

def main():
    total_profit = 0

    for i in range(3):
        print(f"\nEnter data for Client {i+1}:")
        client_name = get_valid_input("Enter client name: ")
        loan_amount = get_valid_input("Enter loan amount: ", is_float=True)
        duration = get_valid_input("Enter loan duration in days: ", is_float=True)

        amount_payable, total_interest = calculate_amount_payable(loan_amount, duration)

        print(f"\nClient: {client_name}")
        print(f"Loan Amount: {loan_amount}")
        print(f"Duration: {duration} days")
        print(f"Total Interest: {total_interest}")
        print(f"Amount Payable: {amount_payable}")

        total_profit += total_interest

    print(f"\nTotal profit from all clients: {total_profit}")
if __name__ == "__main__":
    main()
