import random

def generate_student_id(year, course, mode_of_study):
    """
    Generate a VU-standard student ID without student number.
    
    Args:
    year (str): The year of enrollment (e.g., 2025).
    course (str): The course code (e.g., BSF).
    mode_of_study (str): Mode of study (DAY/EVENING/WEEKEND).
    
    Returns:
    str: Generated student ID.
    """
    
    random_section = f"{random.randint(0, 9999):04d}"
    
   
    student_id = f"VU-{course}-{year}-{random_section}-{mode_of_study.upper()}"
    return student_id


year = input("Enter the year of enrollment (e.g., 2025): ")
course = input("Enter the course code (e.g., BSF): ")
mode_of_study = input("Enter the mode of study (DAY/EVENING/WEEKEND): ")

num_students = int(input("Enter the number of students: "))
print("\nGenerated Student IDs:")
for _ in range(num_students):
    student_id = generate_student_id(year, course, mode_of_study)
    print(student_id)