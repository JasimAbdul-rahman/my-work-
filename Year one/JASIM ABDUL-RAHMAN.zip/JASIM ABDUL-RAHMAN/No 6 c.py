import random

def function(*args):
    
    if all(isinstance(arg, bool) for arg in args):
        
        random_numbers = [random.random() for _ in range(3)]
        return sum(random_numbers) / len(random_numbers)
    else:
        return None  


print(function(2.5, 3.4))  
print(function(2, 3, 4, 5))  
print(function("Adam Sandler", "Drew Barrymore")) 
print(function(False))  
